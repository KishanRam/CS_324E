Open the file "group_19_assignment6.pde" in Processing.
Click "Run" to view the animation.
To interact with the swing set, click in the grey circle on the swing of choice and drag the swing to a new position. Release the mouse to let the swing continue normal motion. Press any key to return the person to the top of the slide with a new, random impulse force and to set the seesaw in motion again.