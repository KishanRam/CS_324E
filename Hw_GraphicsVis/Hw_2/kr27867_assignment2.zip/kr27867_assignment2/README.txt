Kishan Ramachandran

To run the code, first press the 'Run' button
Pressing 0 will display the original image
Pressing 1 will display a greyscale image
Pressing 2 will display a high contrast image
Pressing 3 will display a Gaussian Blur smoothed image
Pressing 4 will display a Sobel Edge Detection
Pressing 5 will display a Laplace of a Gaussian Edge Detection
Pressing any other key will return a printed error statement

The image will remain on the screen until the next key is pressed
