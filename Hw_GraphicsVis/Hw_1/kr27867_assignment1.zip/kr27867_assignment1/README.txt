Open kr27867_assignment.pde file, click run to display image of bridge

